//*************** validation of input value on change*************//
function valid(id,vr)
{
	var arr = new Array();
	var object = {};
	object[id] = vr;
	arr.push(object);
	//var arr='Arun';
		$.ajax({
		type: "POST",
		url: SITE_URL+"/offer/isvalid", // Url to which the request is send
		data: {attributes: arr}, // Data sent to server, a set of key/value pairs (i.e. form fields and values)
		success: function(result)   // A function to be called if request succeeds
		{
			//alert(result);
			var Data=JSON.parse(result);
			$.each(Data,function(ID, ErroMSG){
				//alert(ID+' '+ErroMSG);
				if(ID!="Success")
				{
					$("#er_"+ID).css("display", "block");
					$("#er_"+ID).html(ErroMSG);
				}
				else
				{
					$("#er_"+id).css("display", "none");
				}
			}); 
			
		}
	});
		
}


//***********Action with submit btn***************//
function SbmtLtr()
{
	//var BtnId=$('#SbmtBtn').val();
	//alert(BtnId);
		var arr = new Array();
		var object = {};
	  	$('#FrmArun').find(':input').each(function() {
			id=$(this).attr('id');
			type=$(this).attr('type');
			//alert(id);
			if(type=="checkbox")
			{
				vl= $('#'+id).is(':checked');
			}
			else if(type=="file")
			{
				var file = $("#file")[0].files[0];
				object['fileName']="";
				if(file)
				{
					object['fileName'] = file.name;
					object['fileSize'] = file.size;
					object['fileType'] = file.type;
					//alert(file.type);
				}
			}
			else
			{
				vl=$(this).val();
			}
			if (type!='file')
			{
				//alert(id+"____"+vl);
				object[id] = vl;
			}
		
		});
	arr.push(object);
	var data = {attributes: arr};
	$.ajax({
		type: "POST",
		url: SITE_URL+"/offer/onsubmit",
	   	data: data,
		success: function(result)   // A function to be called if request succeeds
		{
		//alert(result);
			var Data=JSON.parse(result);
			$.each(Data,function(id, ErroMSG){
				if(id=="Success")
				{
					//alert("dfg");
					$('#FrmArun').modal('toggle');
					window.location.href = SITE_URL+'/offer';
				}
				else
				{
					$("#er_"+id).css("display", "block");
					$("#er_"+id).html(ErroMSG);
				}
			}); 
		}
	});
	
}

function Dlt()
{
	
		//alert("himank");
		var arr = new Array();
		var object = {};
	  	$('#DltMdl').find(':input').each(function() {
		id=$(this).attr('id');
        vl=$(this).val();
		type=$(this).attr('type');
			if(type=="hidden")
			{
				//alert(id+"____"+vl);
				object[id] = vl;
			}
		});
	object['Action1'] = 'Preview';
	arr.push(object);
	var data = {attributes: arr};
	$.ajax({
		type: "POST",
		url: "Entity/ltrphp.php",
	   	data: data,
		success: function(result)   // A function to be called if request succeeds
		{
			
			//alert(result);
			var Data=JSON.parse(result);
			$.each(Data,function(id, ErroMSG){
				if(id=="Success")
				{
					$('#DltMdl').modal('toggle');
					window.location.href = SITE_URL+'/offer';
				}
				else
				{
					$("#er_"+id).css("display", "block");
					$("#er_"+id).html(ErroMSG);
				}
			});
		}
	});
	
}
function GetBack()
	{
		var vl= DATA;
		$.each(vl, function (id, vl) {
			if(id!="LtrPopHdr")
			{
				$("#"+id).val(vl);
			}
			else
			{
				$("#"+id).html(vl);
			}
		});
	}


	
$(document).ready(function(){
    $("input").change(function(){
	var id=$(this).attr("id");
	var vr=$(this).val();
	valid(id,vr);
	});
	$("textarea").change(function(){
	var id=$(this).attr("id");
	var vr=$(this).val();
	valid(id,vr);
	});
	$("select").change(function(){
	var id=$(this).attr("id");
	var vr=$(this).val();
	valid(id,vr);
	});
	$("#SbmtBtn").click(function() {
	SbmtLtr();
		
	});
	$("#DltBtn").click(function() {
		//alert("jj");
		Dlt();
	});
	GetBack();
});