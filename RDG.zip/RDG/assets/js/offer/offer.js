
function Frm()
{
	$("#AddCntr").click(function() {
		var id="AddCntr";
		//alert(SITE_URL);
		$.ajax({
		type: "POST",
		url: SITE_URL+"/offer/AddOffer",
	   	data: {ID:id},
			success: function(result)   // A function to be called if request succeeds
			{
				//alert(result);
				$("#ModalBox").html(result);
				$('#FrmArun').modal('toggle');
				$('#SbmtBtn').val('Submit');
			}
		});
	});
}
function FrmEdit()
{
	$(".Edit").click(function() {
		var id=$(this).attr('id');
		//alert(id);
		var  res= id.split("_");
		id=res[0];
		var LtrID=res[1];
		$.ajax({
		type: "POST",
		url: SITE_URL+"/offer/EditOffer",
	   	data: {ID:id,LtrID:LtrID},
			success: function(result)   // A function to be called if request succeeds
			{
				//alert(result);
				$("#ModalBox").html(result);
				$('#FrmArun').modal('toggle');
				$('#SbmtBtn').val('Edit');
				//$('#LgTEml').prop('disabled', true);
			}
		});
	});
}

function LtrPrint()
{
	$(".print").click(function() {
		var id=$(this).attr('id');
		//alert(id);
		var  res= id.split("_");
		id=res[0];
		var LtrID=res[1];
		//alert(LtrID);
		$.ajax({
		type: "POST",
		url: SITE_URL+"offer/printletter",
	   	data: {ID:id,LtrID:LtrID},
			success: function(result)   // A function to be called if request succeeds
			{
			//alert(result);
			$("#ModalBox").html(result);
			var divToPrint=document.getElementById('ModalBox');
			var newWin=window.open('','Print-Window');
			newWin.document.open();
			newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');
			newWin.document.close();
			setTimeout(function(){newWin.close();
			location.reload();
			//window.location.href = "TableBill.php";
			},5);
				
			}
		});
	});
}

function FrmDelete()
{
	$(".delete").click(function() {
		var id=$(this).attr('id');
		//alert(id);
		var  res= id.split("_");
		id=res[0];
		var LtrID=res[1];
		
		$.ajax({
		type: "POST",
		url: "Entity/LtrPop.php",
	   	data: {ID:id,LtrID:LtrID},
			success: function(result)   // A function to be called if request succeeds
			{
				$("#ModalBox").html(result);
				$('#DltMdl').modal('toggle');
				
			}
		});
	});
}
$(document).ready(function(){
   //alert("sdnf,znc");
	//Click2Login();
	//LoginFrm();
	
	Frm();
	FrmEdit();
	FrmDelete();
	LtrPrint();
	$('li').removeClass("active");
    $("#CntrLi").addClass('active');
	 $('#dataTable').DataTable({
			 "bStateSave": true
		});
	
});

