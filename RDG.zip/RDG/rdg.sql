-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2019 at 05:18 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rdg`
--

-- --------------------------------------------------------

--
-- Table structure for table `crs_detail`
--

CREATE TABLE `crs_detail` (
  `CrsID` int(6) NOT NULL,
  `CrsName` varchar(200) NOT NULL,
  `CrsDurY` int(2) NOT NULL,
  `CrsDurM` int(2) NOT NULL,
  `CrsFee` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crs_detail`
--

INSERT INTO `crs_detail` (`CrsID`, `CrsName`, `CrsDurY`, `CrsDurM`, `CrsFee`) VALUES
(1, 'B.Sc Maths  (Hons.)', 3, 0, 40000),
(2, 'B.Sc Physics  (Hons.)', 3, 0, 40000),
(3, 'B.Sc Biotechnology', 3, 0, 40000),
(5, 'B.Sc Medical', 3, 0, 35000),
(8, 'M.Sc Botany', 2, 0, 40000),
(9, 'M.Sc Chemistry', 2, 0, 40000),
(10, 'M.Sc Mathematics', 2, 0, 40000),
(11, 'M.Sc Microbiology', 2, 0, 40000),
(12, 'M.Sc Physics', 2, 0, 40000),
(13, 'Certificate Course in Aesthetic Dentistry', 1, 0, 150000),
(14, 'Certificate Course in Oral Implantology', 1, 0, 150000),
(15, 'Diploma in Dental Hygienist', 2, 0, 40000),
(16, 'Diploma in Dental Mechanic', 1, 0, 40000),
(17, 'BDS', 4, 0, 280000),
(18, 'MDS', 3, 0, 685000),
(19, 'BCA', 3, 0, 40000),
(20, 'MCA', 3, 0, 60000),
(21, 'MCA  (LEET)', 2, 0, 64200),
(22, 'B.Tech-Biotechnology', 4, 0, 100000),
(23, 'B.Tech-Computer Science and Engineering', 4, 0, 100000),
(24, 'B.Tech-Computer science and Engineering with option for specialization in Cloud Technology And Infor', 4, 0, 100000),
(25, 'B.Tech-Computer science and Engineering with option for specialization in Data Science', 4, 0, 100000),
(26, 'B.Tech-Mechanical Engineering  (Robotics and Automation)', 4, 0, 100000),
(27, 'B.Tech-Mechanical Engineering (Automobile Engineering)', 4, 0, 100000),
(28, 'B.Tech-Mechanical Engineering (Mechatronics)', 4, 0, 100000),
(29, 'M.Tech-Civil Engg.  (Environmental Engg.)', 2, 0, 80000),
(30, 'M.Tech-Civil Engg.  (Structural Engg.)', 2, 0, 80000),
(31, 'M.Tech-Civil Engg.  (Transportation Engg.)', 2, 0, 80000),
(32, 'M.Tech-Computer Engg.', 2, 0, 80000),
(33, 'M.Tech-Mechanical Eng.  (Manufacturing Systems)', 2, 0, 80000),
(34, 'M.Tech-Mechanical Engg.  (CAD/CAM)', 2, 0, 80000),
(35, 'M.Tech-Mechanical Engg.  (Robotics and Automation)', 2, 0, 80000),
(36, 'B.Tech-Biotechnology (Lateral Entry)', 3, 0, 107000),
(37, 'B.Tech-Civil Engineering', 4, 0, 100000),
(38, 'B.Tech-Civil Engineering (Lateral Entry)', 3, 0, 107000),
(39, 'B.Tech-Computer Science and Engg. With specialization in Software Development Program (American Patt', 4, 0, 217000),
(40, 'B.Tech-Computer Science and Engineering (Lateral Entry)', 3, 0, 107000),
(41, 'B.Tech-Electrical Engineering', 4, 0, 100000),
(42, 'B.Tech-Electrical Engineering (Lateral Entry)', 3, 0, 107000),
(43, 'B.Tech-Electronics and Comm. Engineering (Lateral Entry)', 3, 0, 107000),
(44, 'B.Tech-Electronics and Comm. Engineering (with optional Internet of Things)', 4, 0, 100000),
(45, 'B.Tech-Mechanical Engineering (Lateral Entry)', 3, 0, 107000),
(46, 'M.Tech-Elect. and Comm. Engg', 2, 0, 80000),
(47, 'M.Tech-Electrical Engg.', 2, 0, 80000),
(48, 'B.Sc Food Science  (Food Technology)', 3, 0, 40000),
(49, 'BHM & CT  (Lateral Entry)', 3, 0, 53500),
(50, 'B.Sc Food Science  (Dietetics and Nutrition)', 3, 0, 40000),
(51, 'B.Sc Hospitality and Catering Management', 3, 0, 50000),
(52, 'BHM & CT', 4, 0, 50000),
(53, 'Diploma in Airlines Tourism and Hospitality Management', 1, 6, 30000),
(54, 'Diploma in Bakery and Confectionery', 1, 6, 30000),
(55, 'Diploma in Food Production', 1, 6, 30000),
(56, 'Diploma in Health and Fitness Nutrition', 1, 6, 30000),
(57, 'Diploma in Room Division Management', 1, 6, 30000),
(58, 'M.Sc (Dietetics and Nutrition)', 2, 0, 40000),
(60, 'B.Com-LLB', 5, 0, 45000),
(61, 'BA-LLB', 5, 0, 45000),
(62, 'BBA-LLB', 5, 0, 45000),
(63, 'LLM', 2, 0, 45000),
(64, 'MBA (Dual Specialization)-Agri Business and Management', 2, 0, 80000),
(65, 'Post Graduate Diploma in Management- Business Analytics', 3, 0, 50000),
(66, 'B.Com. (Hons.)', 3, 0, 50000),
(67, 'BBA', 3, 0, 50000),
(68, 'BBA (LEET)', 2, 0, 50000),
(69, 'MBA (Dual Specialization)-Finance Mgt.', 2, 0, 80000),
(70, 'MBA (Dual Specialization)-Hospital Mgt.', 2, 0, 80000),
(71, 'MBA (Dual Specialization)-Hospitality Mgt.', 2, 0, 80000),
(72, 'MBA (Dual Specialization)-HR Management', 2, 0, 80000),
(73, 'MBA (Dual Specialization)-Information Tech.', 2, 0, 80000),
(74, 'MBA (Dual Specialization)-International Business', 2, 0, 80000),
(75, 'MBA (Dual Specialization)-Marketing Mgt.', 2, 0, 80000),
(76, 'B.Sc (Optom.)LEET', 2, 0, 53500),
(77, 'B.Sc (Optom.)', 3, 0, 50000),
(78, 'B.SC (DIALYSIS THERAPY)', 3, 0, 50000),
(79, 'B.Sc  (Respiratory Therapy)', 0, 0, 0),
(80, 'B.Sc (Cardio Vascular Technology)', 3, 0, 60000),
(81, 'B.Sc (MLT)', 3, 0, 50000),
(82, 'B.Sc (MLT)LEET', 2, 0, 53500),
(83, 'B.Sc (OTT)', 3, 0, 50000),
(84, 'B.Sc (OTT) LEET', 2, 0, 53500),
(85, 'B.Sc (Radiogarphy & Imaging Technology)', 3, 0, 50000),
(86, 'B.Sc (Radiography and Imaging Technology)  (Lateral Entry)', 0, 0, 50000),
(87, 'B.Sc (Radiotherapy)', 3, 0, 50000),
(88, 'Bachelor in Audiology and Speech language Pathology  (BASLP)', 3, 0, 40000),
(89, 'DMLT', 3, 0, 30000),
(90, 'M.Sc (Medical)-Bio-chemistry', 3, 0, 80000),
(91, 'M.Sc (Medical)-Microbiology', 3, 0, 80000),
(92, 'M.Sc (MLT)', 2, 0, 50000),
(93, 'M.Sc (OTT)', 2, 0, 50000),
(94, 'M.Sc (Radiogarphy & Imaging Technology)', 2, 0, 80000),
(95, 'B.Sc (NURSING)', 4, 0, 65000),
(96, 'B.Sc (NURSING) MMIN', 4, 0, 65000),
(97, 'Post Basic B.Sc (NURSING)', 2, 0, 65000),
(98, 'M.Sc Nursing (Medical Surgical Nursing)', 2, 0, 125000),
(99, 'GNM', 3, 0, 66067),
(100, 'B. Pharm', 4, 0, 80000),
(101, 'B. Pharm (Lateral Entry to II yr)', 3, 0, 85600),
(102, 'M. Pharm (Pharmaceutics)', 2, 0, 120000),
(103, 'M. Pharm (Pharmacology)', 2, 0, 120000),
(104, 'M. Pharm (Quality Assurance)', 2, 0, 120000),
(105, 'Pharm. D', 6, 0, 110000),
(106, 'Pharm. D (Post Baccalaureate)', 3, 0, 142000),
(107, 'BPT', 4, 0, 65000),
(108, 'MPT ( Sports)', 4, 0, 60000),
(109, 'MPT  (Cardiopulmonary)', 4, 0, 60000),
(110, 'MPT (Neuro)', 4, 0, 60000),
(111, 'MPT (Ortho)', 4, 0, 60000),
(112, 'MPT (Paediatrics)', 4, 0, 60000),
(113, 'M.SC Nursing (Child Health)', 2, 0, 125000);

-- --------------------------------------------------------

--
-- Table structure for table `ltr_offered`
--

CREATE TABLE `ltr_offered` (
  `LtrID` int(5) NOT NULL,
  `StName` varchar(50) NOT NULL,
  `StNatlty` varchar(50) NOT NULL DEFAULT '0',
  `StEml` varchar(200) NOT NULL DEFAULT '0',
  `CrsID` int(5) NOT NULL,
  `FeeOfrd` varchar(7) NOT NULL,
  `CrsFAdv` varchar(6) NOT NULL,
  `CrsStDt` varchar(10) NOT NULL,
  `CrsEndDt` varchar(10) NOT NULL,
  `IsuDt` date NOT NULL,
  `SchOfrd` varchar(2) NOT NULL,
  `RgFee` varchar(7) NOT NULL,
  `HstlFee` varchar(7) NOT NULL,
  `MinDps` varchar(7) NOT NULL,
  `TtlF1Y` varchar(7) NOT NULL,
  `BArU` varchar(7) NOT NULL,
  `BOct` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ltr_offered`
--

INSERT INTO `ltr_offered` (`LtrID`, `StName`, `StNatlty`, `StEml`, `CrsID`, `FeeOfrd`, `CrsFAdv`, `CrsStDt`, `CrsEndDt`, `IsuDt`, `SchOfrd`, `RgFee`, `HstlFee`, `MinDps`, `TtlF1Y`, `BArU`, `BOct`) VALUES
(1, 'RUQAYAH ISSA dj', 'NAMIBIA', 'NAMIBIA@www.c', 24, '2200', '800', '2019-01', '2020-01', '0000-00-00', '10', '2', '1', '', '3', '4', '5'),
(2, 'FFFFFFFFFFFFFF', 'BB', 'XXX@ss.ss', 1, '10', '2', '2019-01', '2021-01', '0000-00-00', '1', '4', '3', '', '5', '6', '7'),
(3, 'ss', 'ss', 'ss@sw.f', 1, '100', '10', '2019-01', '2019-01', '0000-00-00', '10', '10000', '10', '', '100', '10', '10'),
(4, 'qq', 'qq', 'qq@qq.c', 1, '11', '11', '2019-01', '2020-01', '0000-00-00', '11', '11', '1111', '', '11', '11', '11'),
(5, 'qq', 'qq', 'qq@qq.c', 1, '11', '11', '2019-01', '2020-01', '0000-00-00', '11', '11', '1111', '', '11', '11', '11'),
(6, 'qq', 'qq', 'qq@qq.c', 1, '11', '11', '2019-01', '2020-01', '0000-00-00', '11', '11', '1111', '', '11', '11', '11'),
(7, 'bbaa', 'fg', 'vh@ggh.n', 2, '15', '15', '2019-01', '2021-01', '0000-00-00', '15', '15', '15', '', '15', '15', '15'),
(8, 'bbaa', 'fg', 'vh@ggh.n', 2, '15', '15', '2019-01', '2021-01', '0000-00-00', '15', '15', '15', '', '15', '15', '15'),
(9, 'g', 'bb', 'yty@fghf.hjhj', 10, '56465', '898', '2019-02', '2020-01', '0000-00-00', '67', '8768', '878', '', '989', '7678', '878'),
(10, 'g', 'bb', 'yty@fghf.hjhj', 10, '56465', '898', '2019-02', '2020-01', '0000-00-00', '67', '8768', '878', '', '989', '7678', '878'),
(11, 'jhjk', 'hhj', 'hh@gff.j', 8, '100', '100', '2019-01', '2020-01', '0000-00-00', '10', '100', '100', '', '100', '100', '100'),
(12, 'RUQAYAH I', 'NAMIBIA', 'NAMIBIA@www.c', 24, '2200', '800', '2019-02', '2020-01', '2019-01-01', '10', '2', '1', '', '3', '4', '5'),
(13, 'jhjk', 'hhj', 'hh@gff.j', 8, '100', '100', '2019-01', '2020-01', '2020-01-01', '10', '100', '100', '', '100', '100', '100');

-- --------------------------------------------------------

--
-- Table structure for table `ul`
--

CREATE TABLE `ul` (
  `LoginID` int(11) NOT NULL,
  `LgTEml` varchar(50) NOT NULL,
  `LgTPwd` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `LoginRight` int(2) NOT NULL,
  `Active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ul`
--

INSERT INTO `ul` (`LoginID`, `LgTEml`, `LgTPwd`, `UserName`, `LoginRight`, `Active`) VALUES
(1, 'arun78gupta', 'Arun786!', 'arun', 2, 1),
(2, 'naveen', 'Naveen1234', 'Naveen', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crs_detail`
--
ALTER TABLE `crs_detail`
  ADD PRIMARY KEY (`CrsID`);

--
-- Indexes for table `ltr_offered`
--
ALTER TABLE `ltr_offered`
  ADD PRIMARY KEY (`LtrID`),
  ADD KEY `se_SectionID` (`StName`) USING BTREE;

--
-- Indexes for table `ul`
--
ALTER TABLE `ul`
  ADD PRIMARY KEY (`LoginID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crs_detail`
--
ALTER TABLE `crs_detail`
  MODIFY `CrsID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;

--
-- AUTO_INCREMENT for table `ltr_offered`
--
ALTER TABLE `ltr_offered`
  MODIFY `LtrID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ul`
--
ALTER TABLE `ul`
  MODIFY `LoginID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
