
<head>
<style>
@media print {
  footer {page-break-after: always;}
}
.no-spacing
{
  margin-top: 0.05em;
  margin-bottom: 0;
  margin-left: 0;
  margin-right: 0;
}


.top-spacing
{
  margin-top: 0.3em;
  margin-bottom: 0;
  margin-left: 0;
  margin-right: 0;
}
.main
{
	margin-top: 2.7in;
	margin-left: 0.5in;
	margin-right: 0.5in;

}

ol{
  margin-top: 1em;
  margin-bottom: 0em;
  margin-left: 0;
  margin-right: 0;
}
.TableData
{
	font-size: 10pt;
}
.Header2
{
	font-size: 11pt;
}
.Normal
{
	font-size: 10pt;
}
.FooterData
{
	font-size: 09pt;
}
</style>
</head>
<div class="main">

		<p class='no-spacing' style="text-align: right; tab-stops: 345.75pt;"><span class="TableData" style="color: red;">15-02-2018</span></p>
		<p class='no-spacing' style="text-align: center;"><strong><span style="font-size: 12.0pt; color: red;">PROVISIONAL ADMISSION LETTER</span></strong></p>
		<p class='no-spacing' style="text-align: center;"><strong><span style="font-size: 12.0pt;">(NOT FOR VISA PURPOSE)</span></strong></p>

		<p class='top-spacing' style="line-height: 115%;"><strong>
			<span style="font-size: 12.0pt; line-height: 115%;">
				Name of the Student&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : 
				<span style="color: red;">
					<?php echo strtoupper($LtrData['StName']); ?>
				</span>
			</span>
		</strong></p>
		<p class='no-spacing' style="line-height: 115%;"><strong>
			<span style="font-size: 12.0pt; line-height: 115%;">Nationality&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : 
			<span style="color: red;"><?php echo strtoupper($LtrData['StNatlty']); ?></span></span></strong></p>
		<p class='top-spacing' style="line-height: 115%;"><strong><span class="Header2" >
			Dear <span style="color: red;"> <?php echo ucwords(strtolower($LtrData['StName'])); ?></span>,</span></strong></p>
		<p class='no-spacing' style="text-align: justify;">
			<span class="FooterData" >
				Thank you for your application to study at MM (Deemed to be University), Mullana (Ambala) Haryana, India. On behalf of the University, I am now pleased to make you a provisional offer of place to undertake the program below, subject to submission of all original documents &amp; student&rsquo;s VISA in the name of M. M. (Deemed to be University), Mullana, Ambala. 
			</span>
		</p>
		<p class='top-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="Header2" >Program Details:</span></strong><span class="Header2" >&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
		<table style="width: 495.9pt; border-collapse: collapse; border: none;" width="661">
			<tbody>
				<tr style="height: 3.5pt;">
					<td style="width: 191.15pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="255">
					<p class='no-spacing'><span class="TableData">Program Name&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="406">
						<p class='no-spacing' style="text-align: justify;"><strong><span class="TableData" style="color: red;"><?php echo $LtrData['CrsName']; ?> </span></strong></p>
					</td>
					</tr>
					<tr style="height: 3.5pt;">
					<td style="width: 191.15pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="255">
						<p class='no-spacing'><span class="TableData">Duration of the Course&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
					</td>
					<td style="width: 304.75pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="406">
						<p class='no-spacing'><strong><span class="TableData" style="color: red;"><?php 
																									if($LtrData['CrsDurY']!=0 && $LtrData['CrsDurM']!=0)
																									{
																										echo $LtrData['CrsDurY']." Years & ".$LtrData['CrsDurM']." Months";
																									} 
																									elseif($LtrData['CrsDurY']!=0 && $LtrData['CrsDurM']==0)
																									{
																										echo $LtrData['CrsDurY']." Years";
																									}
																									elseif($LtrData['CrsDurY']==0 && $LtrData['CrsDurM']!=0)
																									{
																										echo $LtrData['CrsDurM']." Months";
																									}		
																									?> </span></strong></p>
					</td>
					</tr>
					<tr style="height: 8.95pt;">
					<td style="width: 191.15pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt; height: 8.95pt;" width="255">
						<p class='no-spacing'><span class="TableData">Course Start Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
					</td>
					<td style="width: 304.75pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 8.95pt;" width="406">
						<p class='no-spacing'><span class="TableData" style="color: red;">
							<?php 
								$date=$LtrData['CrsStDt']."-01";
								$date = date('F, Y', strtotime($date));
								echo $date; 
							?>
						</span></p>
					</td>
					</tr>
					<tr style="height: 10.25pt;">
					<td style="width: 191.15pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt; height: 10.25pt;" width="255">
						<p class='no-spacing'><span class="TableData">Expected Course End Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
					</td>
					<td style="width: 304.75pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 10.25pt;" width="406">
						<p class='no-spacing'><span class="TableData" style="color: red;">
						<?php 
							$date=$LtrData['CrsEndDt']."-01";
							$date = date('F, Y', strtotime($date));
							echo $date; 
						?>
						</span></p>
					</td>
				</tr>
			</tbody>
		</table>
		
		<p class='top-spacing' style="text-align: justify; line-height: 115%; tab-stops: 0in;"><strong><span class="Header2" >Fee Details:</span></strong></p>
		<table style="width: 496.15pt; margin-left: -.25pt; border-collapse: collapse; border: none;" width="662">
			<tbody>
				<tr style="height: 3.5pt;">
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="255">
						<p class='no-spacing'><span class="TableData">Registration Fees (One Time)</span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="406">
						<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">
							<?php echo "USD ".$LtrData['RgFee']." ";?>(Non-refundable, not a part of tuition fees)</span></p>
					</td>
				</tr>
				<tr style="height: 3.5pt;">
					<td style="width: 191.4pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="255">
						<p class='no-spacing'><span class="TableData">Tuition Fees per Year</span></p>
					</td>
					<td style="width: 304.75pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="406">
						<p class='no-spacing'><span class="TableData" style="color: red;">
						<?php 
							echo 'USD '.$LtrData['FeeOfrd'];
						?>
						</span></p>
					</td>
				</tr>
				<tr>
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="255">
						<p class='no-spacing' style="text-align: justify;"><span class="TableData">Tuition Fees per Year after <span class="TableData" style="color: red;"><?php echo $LtrData['SchOfrd']; ?> </span> Scholarship</span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt;" width="406">
						<p class='no-spacing' style="margin-left: .25pt; text-align: justify; text-indent: -.25pt;"><span class="TableData" style="color: red;">USD <?php echo (100-$LtrData['SchOfrd'])/100*$LtrData['FeeOfrd']; ?></span></p>
					</td>
				</tr>
				<tr>
					<td style="width: 191.4pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="255">
						<p class='no-spacing' style="text-align: justify;"><span class="TableData">Hostel fees (with food) per year</span></p>
					</td>
					<td style="width: 304.75pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="406">
						<p class='no-spacing' style="text-align: justify;"><span class="TableData"><?php echo "USD ".$LtrData['HstlFee']." ";?>(For Non AC Accommodation on twin sharing basis with Continental Meals)/ USD 1450 (For Non AC Accommodation on triple sharing basis with Continental Meals)</span></p>
					</td>
				</tr>
				<tr>
					<td style="width: 191.4pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="255">
						<p class='no-spacing'><span class="TableData">Minimum Deposit before Visa</span></p>
					</td>
					<td style="width: 304.75pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="406">
						<p class='no-spacing' style="text-align: justify;"><span class="TableData" style="color: red;"><?php echo "USD ".$LtrData['CrsFAdv']." ";?></span><span class="TableData">(Part of first year fees)</span></p>
					</td>
				</tr>
				<tr>
					<td style="width: 496.15pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" colspan="2" width="662">
						<p class='no-spacing' style="text-align: justify;"><span class="TableData">For continuation of Scholarship from second year onwards, student must attend 75% of the classes, atleast score 7.0 GPA in end semester/year examination, follow Fee Payment schedule as mentioned in Provisional Admission letter &amp; as per the University rules and not indulge in any activity of Indiscipline.</span></p>
					</td>
				</tr>
			</tbody>
		</table>

		<p class='top-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="Header2" >Banking Details: </span></strong><span class="Header2" >The fees can be transferred either by Banker&rsquo;s Draft or swift transfer favoring as stated.</span></p>

		<table style="width: 496.15pt; margin-left: -.25pt; border-collapse: collapse; border: none;" width="662">
		<tbody>
		<tr>
		<td style="width: 198.45pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="265">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="TableData">Intermediary Bank&nbsp;&nbsp;&nbsp;&nbsp; </span></strong></p>
		</td>
		<td style="width: 297.7pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt;" width="397">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">Bank of America (Newyork)</span></p>
		</td>
		</tr>
		<tr>
		<td style="width: 198.45pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="265">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="TableData">NOSTRO A/C No</span></strong><span class="TableData">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
		</td>
		<td style="width: 297.7pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="397">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">6550-4-92111</span></p>
		</td>
		</tr>
		<tr>
		<td style="width: 198.45pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="265">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="TableData">Swift ID CODE</span></strong><span class="TableData"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span></p>
		</td>
		<td style="width: 297.7pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="397">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">BOFAUS3NXXXX</span></p>
		</td>
		</tr>
		<tr>
		<td style="width: 198.45pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="265">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="TableData">ABA CODE</span></strong><span class="TableData"> &nbsp;&nbsp; </span></p>
		</td>
		<td style="width: 297.7pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="397">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">026009593</span></p>
		</td>
		</tr>
		<tr>
		<td style="width: 198.45pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="265">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="TableData">For final beneficiary</span></strong></p>
		</td>
		<td style="width: 297.7pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="397">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">M.M. (Deemed to be University)</span></p>
		</td>
		</tr>
		<tr>
		<td style="width: 198.45pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="265">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="TableData">Account No.</span></strong></p>
		</td>
		<td style="width: 297.7pt; border-top: none; border-left: none; border-bottom: solid black 1.0pt; border-right: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="397">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">51821131000790</span></p>
		</td>
		</tr>
		<tr style="height: 8.05pt;">
		<td style="width: 496.15pt; border: solid black 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt; height: 8.05pt;" colspan="2" width="662">
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData">Account with Oriental Bank of Commerce, Ambala Cantt (Swift address: ORBCINBBABC)</span></p>
		</td>
		</tr>
		</tbody>
		</table>
		<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><strong><span class="Header2" >Note:</span></strong><span class="Header2" > Please mention name of student and remitter in swift message for immediate application of funds.</span></p>

		<p class='no-spacing'><strong><span class="Header2" >Refund policy:</span></strong></p>
		<p class='no-spacing' style="text-align: justify;"><span class="Normal" >In case of visa refusal tuition fees that already paid are refundable within 15 working days after deducting <strong>USD 200</strong> administrative fees. After payment of the fee prescribed above, a Bonafide Letter will be issued, based on which you can apply for the Visa at the Indian High Commission/Embassy, accredited for your country.</span></p>
		<table style="width: 496.15pt; margin-left: -.25pt; border-collapse: collapse; border: none;" width="662">
			<tbody>
				<tr style="height: 3.5pt;">
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt; text-align:center;" colspan="2" width="650">
						<p class='no-spacing'><span class="TableData"><b>Registration Fees (One Time)</b></span></p>
					</td>
				</tr>
				<tr style="height: 3.5pt;">
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="800">
						<p class='no-spacing'><span class="TableData">Total Fee Of First Year</span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="50">
						<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData"><?php echo "USD ".$LtrData['TtlF1Y']." ";?></span></p>
					</td>
				<tr>	
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="800">
						<p class='no-spacing'><span class="TableData">Minimum Deposit before Visa</span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="50">
						<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData"><?php echo "USD ".$LtrData['CrsFAdv']." ";?></span></p>
					</td>
				</tr>
				<tr>
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="800">
						<p class='no-spacing'><span class="TableData">On or before Arrival at MMDU</span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="50">
						<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData"><?php echo "USD ".$LtrData['BArU']." ";?></span></p>
					</td>
				</tr>
				<tr>
					<td style="width: 191.4pt; border: solid black 1.0pt; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="800">
						<p class='no-spacing'><span class="TableData">On or before 30<sup>th</sup> October</span></p>
					</td>
					<td style="width: 304.75pt; border: solid black 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt; height: 3.5pt;" width="50">
						<p class='no-spacing' style="text-align: justify; tab-stops: 0in;"><span class="TableData"><?php echo "USD ".$LtrData['BOct']." ";?></span></p>
					</td>
				</tr>
				
			</tbody>
		</table>
		
		<p class='no-spacing' style="margin-left: .25in; text-align: right;"><span class="FooterData" >Page 01 of 03</span></p>
</div>
<footer>
</footer>
<div class="main" style="margin-top: 2.9in;">
		
		<p class='top-spacing' style="text-align: justify;"><strong><span class="Header2" >Terms &amp; Conditions for Admission:</span></strong></p>
		<ol class="no-spacing" >
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >As per the guidelines of the Government of India, International Students (except students from Nepal &amp; Bhutan) have to register with local Foreigner Regional Registration Office (FRRO) within 14 days of their arrival in India.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Hostel fee and other fee component may vary from year on year.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Bank charges applicable in case on bank transfer etc will be borne by the student/applicant.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >You will have to pay Tuition fees, Hostel Fees, Examination Fees and any other dues within the stipulated time as per the following schedule: </span></div></li>
		</ol>
		
		<table style="width: 475.55pt; margin-left: 13.25pt; border-collapse: collapse; border: none;" width="634">
		<tbody>
		<tr>
		<td style="width: 1.75in; border: solid windowtext 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="168">
		<p class='no-spacing' style="margin-left: 0in; text-align: justify;"><span class="TableData">First Year Tuition and Hostel Fee</span></p>
		</td>
		<td style="width: 207.0pt; border: solid windowtext 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt;" width="276">
		<p class='no-spacing' style="text-align: justify; text-autospace: none;"><span class="TableData">50% of Tuition fee and 50% of Annual Hostel fee on first day of arrival in University.</span></p>
		</td>
		<td style="width: 142.55pt; border: solid windowtext 1.0pt; border-left: none; padding: 0in 5.4pt 0in 5.4pt;" width="190">
		<p class='no-spacing' style="margin-left: .05in; text-align: justify; text-autospace: none;"><span class="TableData">Balance Tuition &amp; Hostel Fee within Three months of arrival in University but not later than October 30th</span></p>
		</td>
		</tr>
		<tr>
		<td style="width: 1.75in; border: solid windowtext 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt;" width="168">
		<p class='no-spacing' style="text-align: justify; text-autospace: none;"><span class="TableData">Second year onwards Tuition </span><span class="TableData">&amp; Hostel Fee</span></p>
		</td>
		<td style="width: 207.0pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="276">
		<p class='no-spacing' style="text-align: justify; text-autospace: none;"><span class="TableData">One semester Tuition &amp; Hostel Fee on or before April 30th.</span></p>
		</td>
		<td style="width: 142.55pt; border-top: none; border-left: none; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; padding: 0in 5.4pt 0in 5.4pt;" width="190">
		<p class='no-spacing' style="text-align: justify; text-autospace: none;"><span class="TableData">Balance Tuition &amp; Hostel Fee on or before October 30th.</span></p>
		</td>
		</tr>
		<tr style="height: 58.4pt;">
		<td style="width: 475.55pt; border: solid windowtext 1.0pt; border-top: none; padding: 0in 5.4pt 0in 5.4pt; height: 58.4pt;" colspan="3" width="634">
		<p class='no-spacing' style="margin-left: .25in; text-align: justify; text-indent: -.25in;"><span class="TableData">Same schedule has to be followed for all subsequent years.</span></p>
		<p class='no-spacing' style="margin-left: 0in; text-align: justify;"><span class="TableData">Request for extension in date for fees payment shall not be entertained in any condition. </span><span class="TableData">Any delay in fees payment will result in not being eligible to register for classes which will lead to shortage of attendance and attendance shall be counted from the first date of starting of semester or academic year, not from the date of fees payment.</span></p>
		</td>
		</tr>
		</tbody>
		</table>
		<ol class="no-spacing" start="5">
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >For the students opting to stay at International Hostel, an upper limit of 80 KWH and 130 KWH per month has been fixed for electricity consumption in a non-Air Conditioned and Air Conditioned room respectively. If consumption is upto this limit, students need not to pay anything. In case the electricity consumption is more than the prescribed limit, the student will have to pay for the additional consumption, as per the rules.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >In order to obtain a Visa, you must ensure that you or your sponsor can pay the full tuition and hostel fee and can provide at least USD 100 per month as routine additional expenses to support yourself and you should be prepared to provide evidence of this to the Indian Embassy/High Commission and at immigration.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >If your application for Visa is accepted but you decide not to attend the M M (</span><span class="Normal" >Deemed to be University)</span><span class="Normal" > or you withdraw from this University, the University will inform the concerned Ministry immediately, which will have an impact on your Visa status. This University will not process any application to transfer to other institutions.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >If you wish to leave the course mid-stream, you will be required to deposit the fee for the remaining period of the course.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Smoking, Consumption of Intoxicants/ Drugs and Alcohol is Strictly Prohibited inside the Hostel and University campus. Entry in the University campus and Hostel after consuming Intoxicants /Drugs and Alcohol outside is also not allowed. Any violation in this regard shall attract heavy fine and strict disciplinary action, as per rules of University.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Minimum 75% attendance in all the subjects is required for appearing in final end semester examinations. </span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Involvement in any sort of aggressive behavior, violence or disturbance within University campus with faculty, staff and students and outside the University campus shall invite strict disciplinary action including Rustication from University authorities and Government law enforcing agencies.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Entering and visiting (even for a very less time) girls hostel by boys and boys hostel by Girls is strictly not allowed at any time.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Hostel fee will not be refunded in case of expulsion. If student leave the hostel on own will in between the academic session, hostel fee will not be refunded. Hostel fees for one year is counted from July to June month and even in case of late joining, student has to pay complete year&rsquo;s Hostel fees.</span></div></li>
			<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >Student will be responsible to inform the authorities about the visa renewal (i.e. at least three months before) or leaving for vacation (i.e. at least one month before) well in advance.</span></div></li>
		<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >In the larger interest of students, MM (</span><span class="Normal" >Deemed to be University)</span><span class="Normal" > Authorities can enforce any other regulations in future as per the need/circumstances.</span></div></li>
		</ol>
		
	<footer>
		<p class='no-spacing' style="margin-left: .25in; text-align: right;"><span class="FooterData" >Page 02 of 03</span></p>
	</footer>	
</div>

<div class="main">		
	<p class='no-spacing' style="margin-left: .25in; text-align: right;"><span class="Header2" >&nbsp;</span></p>
	<ol class="no-spacing" start="16">
		
		
		<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >It is mandatory to stay in on campus MMDU Hostel. It will be beneficial for security, study and for availing Medical Facilities, sports facilities, library facilities and computing facilities. On campus stay in MMDU Hostel will also be helpful in getting Visa extensions.</span></div></li>
		<li style="margin-left: -.25in; text-align: justify;" > <div style="margin-left:.1in;"><span class="Normal" >For continuous absence of one week from classes or hostel without prior permission from the competent authorities, action will be taken against you as per University rules and your parents/Guardians/Embassy may be contacted by the concerned Institute/Department/International Affairs office.</span></div></li>
	</ol>
	<p class='no-spacing' style="text-align: justify; tab-stops: 40.5pt; text-autospace: none;"><span class="Header2" >&nbsp;</span></p>
	<p class='no-spacing' style="text-align: justify; tab-stops: 40.5pt; text-autospace: none;"><span class="Header2" >&nbsp;</span></p>
	<p class='no-spacing' style="text-align: justify; tab-stops: 40.5pt; text-autospace: none;"><span class="Header2" >&nbsp;</span></p>
	<p class='no-spacing' style="text-align: justify;"><strong><span class="Header2" >&nbsp;</span></strong></p>
	<p class='no-spacing' style="text-align: justify;"><strong>Joint Director (International Affairs)</strong></p>
	<p class='no-spacing' style="text-align: justify;">E-mail ID: <a href="mailto:interedu@mmumullana.org">interedu@mmumullana.org</a></p>
	<p class='no-spacing' style="text-align: right;">&nbsp;</p>
	<p class='no-spacing' style="text-align: right;"><span class="Header2" >&nbsp;</span></p>
	<p class='no-spacing' style="text-align: right;"><span class="Header2" >&nbsp;</span></p>
	<footer>
		<p class='no-spacing' style="margin-left: .25in; text-align: right;"><span class="FooterData" >Page 03 of 03</span></p>
	</footer>
</div>