 <!-- Bootstrap core JavaScript-->
 <script type="text/javascript">
    var SITE_URL = "<?php echo site_url();?>";
</script> 
 <script src="<?php echo base_url();?>assets/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url();?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url();?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url();?>assets/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="<?php echo base_url();?>assets/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo base_url();?>assets/js/offer/offer.js"></script>


<?php
include('navbar.php');
if(isset($_SESSION['LoginID']))
{
	
	if($_SESSION['LoginID']>0)
	{
	foreach($Offers[0] as $k=>$v)
	{
		$TableContent[]=$k ;
    }
	$TableWidth=array( "50","300","200", "200","200", "100", "50", "50", "50",  "50","50","50", "50", "50",  "50","50","50" ,"50","50");
	//$TableAlign=array( "CFL","RFL","CFL", "LFL","LFL", "LFL", "LFL", "LFL", "LFL",  "LFL","CFL","CFL" );
	?>

	<!-- Begin Page Content -->
	<div class="container-fluid">
	
	<div id="ModalBox">
		</div>
			

			


		
			  <!-- DataTales Example -->
			  <div class="card shadow mb-4">
				<div class="card-header py-3">
					<span class="m-0 font-weight-bold text-primary">Offer Letter Record</span>
					<button class="btn btn-info btn-icon-split" id="AddCntr" style="float:right">
						<span class="icon text-white-50">
						  <i class="fas fa-info-circle"></i>
						</span>
						<span class="text">Add New Letter</span>
					</button>
				</div>
				<div class="card-body">
				  <div class="table-responsive">
					<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					  <thead>
						<tr>
						<?php
						foreach($TableContent as $k=> $v)
							{
								echo "<th class='CFL' style='max-width:200px;min-width:".$TableWidth[$k]."'>	$v	</th>";
							}
						?>
						<th >Offer Letter</th>
						<th >Action</th>
						</tr>
					  </thead>
					  <tbody>
						<?php 
						$u=1;
						foreach($Offers as $TableData)
						{
						?>
							<tr>
							<?php
							foreach ($TableContent as $value)
							{
									if($value!="Sr. No.")
									{
										echo "<td>".$TableData->$value."</td>";
									}
									else
									{
										echo "<td> $u </td>";
										
									}
									
							}
									$u=$u+1;
									$id="Sr. No.";
								?>
								
									<td>
										<button type="button" class="btn btn-warning print" id="<?php echo "PrintBtn_".$TableData->$id;?>">Print</button>
									</td>
									<td>
										<button type="button" class="btn btn-primary edit" style='min-width:75px' id="<?php echo "EditBtn_".$TableData->$id;?>">Edit</button>
									
										<button type="button" class="btn btn-danger delete" style='min-width:75px;margin-top:5px' id="<?php echo "DltBtn_".$TableData->$id;?>">Delete</button>
									</td>
								</tr>
							<?php
							}
							?>
					  </tbody>
					</table>
				  </div>
				</div>
			  </div>

			</div>
			<!-- /.container-fluid -->

		  
		  <!-- Footer -->
		  <footer class="sticky-footer bg-white">
			<div class="container my-auto">
			  <div class="copyright text-center my-auto">
				<span>Copyright &copy; Your Website 2019</span>
			  </div>
			</div>
		  </footer>
		  <!-- End of Footer -->

	  
	  <!-- Scroll to Top Button-->
	  <a class="scroll-to-top rounded" href="#page-top">
		<i class="fas fa-angle-up"></i>
	  </a>
	  
	  
	<?php
	}
	else
	{
		echo "You are not Authorized to access this page"; 
	}
}
else
{
?>	
	login to enter<br>
	<input type="button" onclick="window.location.href='login.php'" class="btn btn-primary btn-user btn-block" value="Click to Login"/>
<?php
}
?>  
  
  
  

  
  
</body>

</html>
