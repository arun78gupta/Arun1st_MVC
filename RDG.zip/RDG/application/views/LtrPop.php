<style>
.modal-content {
  width: 900px;
  margin: auto;
  margin-left:-200px;
}
</style>
<script>
	var DATA=<?php print json_encode($LtrData); ?>;
</script>
<script src="<?php echo base_url();?>assets/js/offer/ltrpop.js?=5"></script>

<div class="modal fade" id="FrmArun" role="dialog">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="LtrPopHdr">Add New Offer Letter</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">
			<div class="row" style="margin:2px;margin-top:10px;" id="FrmCnt">
				<input id="LtrID" type="hidden" value="<?php echo $LtrID;?>"/>
				<div class="col-lg-6 mb-4">
					<span class="label">Student Name</span>
						<input class="form-control" id="StName" type="text" placeholder="Enter Student Name"/>
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 15px; top: 30px;" id="er_StName"></span>
				</div>
				<div class="col-lg-6 mb-4">
					<span class="label">Email</span>
						<input class="form-control" type="text" id="StEml" placeholder="Enter Email"/>
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 15px; top: 30px;" id="er_StEml"></span>
				</div>
				<div class="col-lg-6 mb-4">
					<span class="label">Program Name</span>
					
					<?php $Cls=array(
										'class'=> 'form-control',
										'id'=>'CrsID'
									);
					echo form_dropdown('CrsID', $Courses, 'N',$Cls);?>
					
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 15px; top: 30px;" id="er_CrsID"></span>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Nationality</span>
						<input class="form-control" id="StNatlty" type="text" placeholder="Enter Student Nationality"/>
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 15px; top: 30px;" id="er_StNatlty"></span>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Issue Date</span>
						<input class="form-control" id="IsuDt" type="date" value= '<?php echo date('Y-m-d');?>'/>
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 15px; top: 30px;" id="er_IsuDt"></span>
				</div>
				
				<div class="col-lg-3 mb-4">
					<span class="label">Tuition Fees/Year</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="FeeOfrd" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 8px;" id="er_FeeOfrd"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Scholarship Offered</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">%</span>
						</div>
						<input class="form-control" id="SchOfrd" type="text" placeholder="Enter Scholarship"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 8px;" id="er_SchOfrd"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Min Deposit before Visa</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="CrsFAdv" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 8px;" id="er_CrsFAdv"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Hostel fees/year</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="HstlFee" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 8px;" id="er_HstlFee"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Registration Fees</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="RgFee" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 10px;" id="er_RgFee"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Total Fee Of First Year</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="TtlF1Y" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 10px;" id="er_TtlF1Y"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Before Arrival at MMDU</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="BArU" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 10px;" id="er_BArU"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Before 30<sup>th</sup> October</span>
					<div class="input-group">
						<div class="input-group-prepend">
							<span class="input-group-text" id="basic-addon1">USD</span>
						</div>
						<input class="form-control" id="BOct" type="text" placeholder="Enter Fee"/>
						<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 5px; top: 10px;" id="er_BOct"></span>
					</div>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Course Start Date</span>
						<input class="form-control" type="month" id="CrsStDt" />
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 20px; top: 0px;" id="er_CrsStDt"></span>
				</div>
				<div class="col-lg-3 mb-4">
					<span class="label">Course End Date</span>
						<input class="form-control" type="month" id="CrsEndDt"/>
					<span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 20px; top: 0px;" id="er_CrsEndDt"></span>
				</div>
			</div>
		</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <input type="button" class="btn btn-info" value="Submit" id="SbmtBtn"/>
		</div>
      </div>
    </div>
  </div>			
			

