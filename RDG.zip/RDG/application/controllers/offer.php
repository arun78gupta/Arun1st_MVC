<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Offer extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		if(!$this->session->userdata('LoginID'))
			return redirect();
		
		$this->load->model('offer_model');
		$Offers=$this->offer_model->offer_list();
		$this->load->helper('form');
		$this->load->view('offer_frm',['Offers'=>$Offers]);
	}
	public function AddOffer()
	{
		$ID=$this->input->post('ID');
		$this->load->helper('form');
		$this->load->model('offer_model');
		$Courses=$this->offer_model->course_list();
		$LtrID='N';
		$LtrData[0]['LtrPopHdr']='Add New Offer Letter';
		$this->load->view('LtrPop',['Courses'=>$Courses,'LtrID'=>$LtrID,'ID'=>$ID,'LtrData'=>$LtrData[0]]);
	}
	
	public function EditOffer()
	{
		$LtrID=$this->input->post('LtrID');
		$ID=$this->input->post('ID');
		$this->load->helper('form');
		$this->load->model('offer_model');
		$Courses=$this->offer_model->course_list();
		$LtrData=$this->offer_model->ltr_data($LtrID);
		$LtrData[0]['LtrPopHdr']='Edit Offer Letter';
		$this->load->view('LtrPop',['Courses'=>$Courses,'LtrID'=>$LtrID,'ID'=>$ID,'LtrData'=>$LtrData[0]]);
	}
	
	public function isvalid()
	{
		$attributes=$this->input->post('attributes');
		$this->load->model('validation');
		$ErrorMSG=$this->validation->isvalid_entry($attributes);
		$ErrorMSG=json_encode($ErrorMSG);
		print_r($ErrorMSG);
	}
	public function onsubmit()
	{
		$attributes=$this->input->post('attributes');
		$this->load->model('validation');
		$ErrorMSG=$this->validation->isvalid_entry($attributes);
		$this->load->model('offer_model');
		//echo $attributes[0]['LtrID'];
		if(isset($ErrorMSG['Success']))
		{
			if($attributes[0]['SbmtBtn']=='Submit')
			{
				$Inserted=$this->offer_model->insert_offer($attributes);
				if($Inserted)
				{
					$ErrorMSG=json_encode($ErrorMSG);
					print_r($ErrorMSG);
				}
				else
				{
					unset($ErrorMSG['Success']);
					$ErrorMSG['SrvrError']='Server Error';
					$ErrorMSG=json_encode($ErrorMSG);
					print_r($ErrorMSG);
				}
			}
			elseif($attributes[0]['SbmtBtn']=='Edit')
			{
				$Updated=$this->offer_model->update_offer($attributes);
				$ErrorMSG=json_encode($ErrorMSG);
				print_r($ErrorMSG);
			}
		}
		else
		{
			$ErrorMSG=json_encode($ErrorMSG);
			print_r($ErrorMSG);
		}
	}
	public function printletter()
	{
		$LtrID=$this->input->post('LtrID');
		$ID=$this->input->post('ID');
		$this->load->model('offer_model');
		$LtrData=$this->offer_model->ltr_data($LtrID);
		$this->load->view('doc1',['LtrData'=>$LtrData[0]]);
	}
	
}
