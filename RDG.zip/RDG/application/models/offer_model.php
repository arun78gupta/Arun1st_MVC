<?php
class Offer_model extends CI_Model{
	public function offer_list()
	{
		$q=$this->db->query("SELECT L.LtrID as 'Sr. No.', 
										concat('<b>Name: </b>',L.StName,'<br><b>Nationality: </b>', L.StNatlty,'<br><b>Email: </b>', L.StEml,'<br><b>Issue Date: </b>', L.IsuDt) as 'Student Detail',
										concat('<b>Course: </b>',C.CrsName,'<br><b>Duration: </b>',concat(C.CrsDurY,' Year ',C.CrsDurM,' Month'),'<br><b>Start Date: </b>', L.CrsStDt,'<br><b>End Date: </b>', L.CrsEndDt) as 'Course Detail',
										concat('<b>Reg Fees: </b>$',L.RgFee,'<br><b>Tuition Fee: </b>',L.FeeOfrd ,'<br><b>Scholarship: </b>',concat(L.SchOfrd,'%'),'<br><b>Hostel Fee: </b>$',L.HstlFee) as 'Course Fee',
										concat('<b>Total Fee 1<sup>st</sup>Y: </b>$',L.TtlF1Y,'<br><b>MinDep bfr Visa: </b>$',L.CrsFAdv,'<br><b>Bfr Arrival: </b>$',L.BArU,'<br><b>Bfr 30,Oct: </b>$',L.BOct) 'Fee Schedule' 
										FROM ltr_offered L,Crs_Detail C 
										where C.CrsID=L.CrsID");
		
			return $q->result();
	}
	public function ltr_data($LtrID)
	{
		//$q=$this->db->query("SELECT `StName`, `StNatlty`, `StEml`, `CrsID`, `FeeOfrd`, `CrsFAdv`, `CrsStDt`, `CrsEndDt`, `SchOfrd`, `RgFee`, `HstlFee`, `MinDps`, `TtlF1Y`, `BArU`, `BOct` FROM `ltr_offered` where LtrID='$LtrID'");
		$q=$this->db->query("SELECT OL.LtrID, OL.StName, OL.StNatlty, OL.StEml, OL.CrsID, OL.FeeOfrd, OL.CrsFAdv, OL.CrsStDt, OL.CrsEndDt,OL.IsuDt, OL.SchOfrd, OL.RgFee,OL.HstlFee,OL.TtlF1Y,OL.BArU,OL.BOct,Crs.CrsName,Crs.CrsDurY,Crs.CrsDurM FROM ltr_offered OL, crs_detail Crs WHERE OL.CrsID=Crs.CrsID and OL.LtrID='$LtrID'");
		return $q->result_array();
	}
	public function course_list()
	{
		$q=$this->db->query("SELECT CrsID, CrsName FROM crs_detail");
		if($q->num_rows()>0) {
		$result = $q->result(); //or $query->result_array() to get an array
		$Arr['N']='Select Course';	
			foreach( $result as $row )
			{
				 $CrsID=$row->CrsID;
				 $CrsName=$row->CrsName;
				 $Arr[$CrsID]=$CrsName;
			}
		} 
		return $Arr;
	}
	public function insert_offer($attributes)
	{
		if(isset($attributes)){
		$ATR=array('StName', 'StNatlty', 'StEml', 'CrsID', 'FeeOfrd', 'CrsFAdv', 'CrsStDt', 'CrsEndDt','IsuDt', 'SchOfrd', 'RgFee', 'HstlFee', 'MinDps', 'TtlF1Y', 'BArU', 'BOct');
			while (list($k,$v)=each($attributes[0]))
			{
				if(in_array($k, $ATR))
				{	
					$data[$k]=$v;
				}
			}
		}
		//print_r($data);
		$this->db->insert('ltr_offered',$data);
		if ($this->db->affected_rows() == '1')
		{
			return TRUE;
		}
		return FALSE;
	}
	public function update_offer($attributes)
	{
		if(isset($attributes)){
		$LtrID=$attributes[0]['LtrID'];	
		$ATR=array('StName', 'StNatlty', 'StEml', 'CrsID', 'FeeOfrd', 'CrsFAdv', 'CrsStDt', 'CrsEndDt','IsuDt', 'SchOfrd', 'RgFee', 'HstlFee', 'MinDps', 'TtlF1Y', 'BArU', 'BOct');
			while (list($k,$v)=each($attributes[0]))
			{
				if(in_array($k, $ATR))
				{	
					$data[$k]=$v;
				}
			}
		}
		//print_r($data);
		$this->db->where('LtrID', $LtrID);
		$this->db->update('ltr_offered',$data);
		if ($this->db->affected_rows() == '1')
		{
			return TRUE;
		}
		return FALSE;
	}
}