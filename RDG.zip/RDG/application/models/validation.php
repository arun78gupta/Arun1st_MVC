<?php
class Validation extends CI_Model{
	public function isvalid_entry($attributes)
	{
	
		//************** data Import for New Submition or Edit old data*************//
		if(isset($attributes)){
			while (list($k,$v)=each($attributes[0]))
			{
				$_POST[$k]=$v;
				//echo $k."_".$v."\n";
				$IsSubmitted="Y";
			}
		}
		
		//*********** Validations for on change and on submit*************//
		if(isset($_POST['StName'])){
			$StName=$_POST['StName'];
			if (empty($_POST["StName"]))
			{
				$ErrorMSG["StName"] = "Req";
			}
			if (!empty($_POST["StName"])) 
			{
				if (preg_match("/[^A-Z a-z]/", $StName))
				{
					$ErrorMSG["StName"] = "A-Z a-z";
				} 
			}
		}
		if(isset($_POST['StNatlty'])){
			$StNatlty=$_POST['StNatlty'];
			if (empty($_POST["StNatlty"]))
			{
				$ErrorMSG["StNatlty"] = "Req";
			}
			if (!empty($_POST["StNatlty"])) 
			{
				if (preg_match("/[^A-Z a-z]/", $StNatlty))
				{
					$ErrorMSG["StNatlty"] = "A-Z a-z";
				} 
			}
		}
		
		if(isset($_POST['StEml'])){
			$StEml=$_POST['StEml'];
			if (empty($_POST["StEml"]))
			{
				$ErrorMSG["StEml"] = "Req";
			}
			elseif (!empty($StEml)) 
			{
				if (!filter_var($StEml, FILTER_VALIDATE_EMAIL)) 
				{
					$ErrorMSG["StEml"] = "Invalid";
				} 
			}
		}
		
		if(isset($_POST['CrsID']))
		{
			$CrsID=$_POST['CrsID'];
			if (preg_match("/[^0-9]/", $CrsID))
			{
				$ErrorMSG["CrsID"] = "Req";
			} 
		}
		
		if(isset($_POST['IsuDt'])){
			$IsuDt=$_POST['IsuDt'];
			if (empty($_POST["IsuDt"]))
			{
				$ErrorMSG["IsuDt"] = "Req";
			}
		}
		
		if(isset($_POST['FeeOfrd'])){
			$FeeOfrd=$_POST['FeeOfrd'];
			if (empty($_POST["FeeOfrd"]))
			{
				$ErrorMSG["FeeOfrd"] = "Req";
			}
			elseif (!empty($FeeOfrd)) 
			{
				if (preg_match("/[^0-9]/",$FeeOfrd)) 
				{
					$ErrorMSG["FeeOfrd"] = "Numeric";
				} 
			}
		}
		if(isset($_POST['SchOfrd'])){
			$SchOfrd=$_POST['SchOfrd'];
			if (empty($_POST["SchOfrd"]))
			{
				$ErrorMSG["SchOfrd"] = "Req";
			}
			elseif (!empty($SchOfrd)) 
			{
				if (preg_match("/[^0-9]/",$SchOfrd)) 
				{
					$ErrorMSG["SchOfrd"] = "Numeric";
				} 
			}
		}
		if(isset($_POST['CrsFAdv'])){
			$CrsFAdv=$_POST['CrsFAdv'];
			if (empty($_POST["CrsFAdv"]))
			{
				$ErrorMSG["CrsFAdv"] = "Req";
			}
			elseif (!empty($CrsFAdv)) 
			{
				if (preg_match("/[^0-9]/",$CrsFAdv)) 
				{
					$ErrorMSG["CrsFAdv"] = "Numeric";
				} 
			}
		}
		
		if(isset($_POST['RgFee'])){
			$RgFee=$_POST['RgFee'];
			if (empty($_POST["RgFee"]))
			{
				$ErrorMSG["RgFee"] = "Req";
			}
			elseif (!empty($RgFee)) 
			{
				if (preg_match("/[^0-9]/",$RgFee)) 
				{
					$ErrorMSG["RgFee"] = "Numeric";
				} 
			}
		}
		if(isset($_POST['HstlFee'])){
			$HstlFee=$_POST['HstlFee'];
			if (empty($_POST["HstlFee"]))
			{
				$ErrorMSG["HstlFee"] = "Req";
			}
			elseif (!empty($HstlFee)) 
			{
				if (preg_match("/[^0-9]/",$HstlFee)) 
				{
					$ErrorMSG["HstlFee"] = "Numeric";
				} 
			}
		}
		if(isset($_POST['TtlF1Y'])){
			$TtlF1Y=$_POST['TtlF1Y'];
			if (empty($_POST["TtlF1Y"]))
			{
				$ErrorMSG["TtlF1Y"] = "Req";
			}
			elseif (!empty($TtlF1Y)) 
			{
				if (preg_match("/[^0-9]/",$TtlF1Y)) 
				{
					$ErrorMSG["TtlF1Y"] = "Numeric";
				} 
			}
		}
		if(isset($_POST['BArU'])){
			$BArU=$_POST['BArU'];
			if (empty($_POST["BArU"]))
			{
				$ErrorMSG["BArU"] = "Req";
			}
			elseif (!empty($BArU)) 
			{
				if (preg_match("/[^0-9]/",$BArU)) 
				{
					$ErrorMSG["BArU"] = "Numeric";
				} 
			}
		}
		
		if(isset($_POST['BOct'])){
			$BOct=$_POST['BOct'];
			if (empty($_POST["BOct"]))
			{
				$ErrorMSG["BOct"] = "Req";
			}
			elseif (!empty($BOct)) 
			{
				if (preg_match("/[^0-9]/",$BOct)) 
				{
					$ErrorMSG["BOct"] = "Numeric";
				} 
			}
		}
		if(isset($_POST['CrsStDt'])){
			$CrsStDt=$_POST['CrsStDt'];
			if (empty($_POST["CrsStDt"]))
			{
				$ErrorMSG["CrsStDt"] = "Req";
			}
		}
		if(isset($_POST['CrsEndDt'])){
			$CrsEndDt=$_POST['CrsEndDt'];
			if (empty($_POST["CrsEndDt"]))
			{
				$ErrorMSG["CrsEndDt"] = "Req";
			}
		}
		//***** send back Error Massage **************//
		if(isset($ErrorMSG))
		{	
			return $ErrorMSG;
		}
		else
		{
			$ErrorMSG["Success"]="No Error";
			return $ErrorMSG;
		}
	}	
}