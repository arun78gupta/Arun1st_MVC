<?php

class UserModel extends CI_Model{
	public function getusers()
	{
		//echo 'test';
		//$this->load->database();
		$q=$this->db->query("Select * from ut_bank");
		return $q->result_array();
		//print_r($q);
	}
	
}