<?php

class Course_model extends CI_Model{
	public function course_list()
	{
		$q=$this->db->query("SELECT CrsID, CrsName FROM crs_detail");
		if( $q->num_rows() > 0) {
		$result = $q->result(); //or $query->result_array() to get an array
		$Arr['N']='Select Course';	
			foreach( $result as $row )
			{
				 $CrsID=$row->CrsID;
				 $CrsName=$row->CrsName;
				 $Arr[$CrsID]=$CrsName;
			}
		} 
		//print_r($Arr);
		return $Arr;
	}
}