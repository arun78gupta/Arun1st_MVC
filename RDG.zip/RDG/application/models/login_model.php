<?php

class Login_model extends CI_Model{
	public function valid_user($username,$password)
	{
		$q=$this->db->query("Select * from ul where LgTEml='$username' and LgTPwd='$password'");
		if($q->num_rows())
		{
			return $q->row()->LoginID;
		}
		else
		{
			return FALSE;
		}
		
	}
	
}